# ERC validation extension - _Under development_

The [basic validation](index.md#validation) mechanism compares hashes of files where this is possible and ignores other files.

This extension goes beyond simple comparison and incorporates "harder" to compare files and what to do with them, e.g. plots/figures, PDFs, ...