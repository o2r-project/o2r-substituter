# Plain container bundling extension

Using the label mechanisms of Docker and OCI, how to package an ERC using _only_ a container and no outer bundle?