# Signature extension - _Under development_

An ERC must be subject to human inspection.
How can we model and trace the involved people in a way that is open to scrutiny?
Examples: reviewers "sign" an ERC which they examined and evaluated, librarians add their signature on receiving and checking a submission to an archive, an author does a self-check and confirms "to his best knowledge" the ERC is OK.
