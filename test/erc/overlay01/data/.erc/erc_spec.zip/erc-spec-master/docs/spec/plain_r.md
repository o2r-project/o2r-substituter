# Plain R runtime extension

The runtime manifest is a codemeta document, and the runtime environment is created outside of a container.