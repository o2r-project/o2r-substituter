# Contributing to this project

## Writing style

- Put each sentence on one line.

## Pull requests

In your first pull request, please state you are contributing under the project license.